# Zenonia 2 — versão 1.0.3: o analógico esquerdo move o personagem também no modo portátil

Causa: o jogo lia o analógico só do controle "jogador 1". No modo portátil os Joy-Cons acoplados
são outro "slot", e o analógico deles era ignorado (só o direcional funcionava). Agora os dois são lidos.

Na ramificação `zenonia2`:

```bash
cd /workspaces/Zenonia_nx
git status                       # deve dizer "nothing to commit"
git checkout zenonia2
unzip -o zenonia2_v103_update.zip
cp -r zenonia2_nx/. . && rm -rf zenonia2_nx zenonia2_v103_update.zip
rm -rf build launcher/build
./build.sh
launcher/build.sh
```

Leve `launcher/zenonia2_nx.nro` para `sd:/switch/zenonia2_nx/` e teste no modo portátil.
